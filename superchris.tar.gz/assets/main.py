import pygame
import os
import math
import random
import sys
import asyncio

# Inicializace Pygame pro WebAssembly / Chrome AudioContext
pygame.mixer.pre_init(frequency=48000, size=-16, channels=2, buffer=1024)
pygame.init()
pygame.mixer.init()
pygame.mixer.set_num_channels(16)

# Nastavení okna
WIDTH, HEIGHT = 1200, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Super Chris")

# Barvy
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
GOLD = (255, 215, 0)
SKY_BLUE = (135, 206, 235)
TRANSPARENT_BLACK = (0, 0, 0, 150)
TRANSPARENT_RED = (255, 0, 0, 128)
FULL_TRANSPARENT = (0, 0, 0, 0)

# Nastavení hry
FPS = 60
clock = pygame.time.Clock()
PIC_DIR = "PIC"
AUDIO_DIR = "AUDIO"

if not os.path.exists(PIC_DIR):
    os.makedirs(PIC_DIR)
if not os.path.exists(AUDIO_DIR):
    os.makedirs(AUDIO_DIR)

def load_image(name, size=None, color=RED):
    path_png = os.path.join(PIC_DIR, name + ".png")
    path_jpg = os.path.join(PIC_DIR, name + ".jpg")
    path_PNG_upper = os.path.join(PIC_DIR, name + ".PNG")
    
    img = None
    if os.path.exists(path_png):
        img = pygame.image.load(path_png).convert_alpha()
    elif os.path.exists(path_jpg):
        img = pygame.image.load(path_jpg).convert_alpha()
    elif os.path.exists(path_PNG_upper):
        img = pygame.image.load(path_PNG_upper).convert_alpha()
        
    if img:
        if size:
            img = pygame.transform.scale(img, size)
        return img
    else:
        surf = pygame.Surface(size if size else (50, 50), pygame.SRCALPHA)
        surf.fill(color)
        return surf

def load_sound(name):
    for ext in [".wav", ".mp3", ".ogg"]:
        path = os.path.join(AUDIO_DIR, name + ext)
        if os.path.exists(path):
            return pygame.mixer.Sound(path)
    return None

def play_music(name):
    for ext in [".mp3", ".wav", ".ogg"]:
        path = os.path.join(AUDIO_DIR, name + ext)
        if os.path.exists(path):
            pygame.mixer.music.load(path)
            pygame.mixer.music.play(-1)
            return True
    return False

# Načtení grafiky
IMG_UVODNI = load_image("UVODNI", (WIDTH, HEIGHT), SKY_BLUE)
IMG_POZADI = load_image("POZADI", (WIDTH, HEIGHT), SKY_BLUE)
IMG_KONEC = load_image("KONEC", (WIDTH, HEIGHT), BLACK)

IMG_CHRIS_00 = load_image("CHRIS_00", (120, 157), (0, 0, 255)) 
IMG_CHRIS_01 = load_image("CHRIS_01", (120, 157), (0, 255, 255)) 
IMG_CHRIS_02 = load_image("CHRIS_02", (120, 157), (255, 255, 0)) 

IMG_CHRIS_00_L = load_image("CHRIS_00_L", (120, 157), (0, 0, 150)) 
IMG_CHRIS_01_L = load_image("CHRIS_01_L", (120, 157), (0, 150, 150)) 
IMG_CHRIS_02_L = load_image("CHRIS_02_L", (120, 157), (150, 150, 0)) 

IMG_HOUBA_RED = load_image("HOUBA_RED", (60, 60), RED)
IMG_HOUBA_GREEN = load_image("HOUBA_GREEN", (60, 60), GREEN) 
IMG_MINCE = load_image("MINCE", (40, 40), GOLD)
IMG_MINCE2 = load_image("MINCE2", (40, 40), GOLD) 
IMG_CIHLY = load_image("CIHLY", (150, 45), (139, 69, 19))
IMG_NAPIS = load_image("NAPIS", (400, 69), TRANSPARENT_BLACK)

# Dotyková tlačítka nahrazena za dvě poloviční
IMG_RUN_L = load_image("RUN_L", (100, 200), TRANSPARENT_BLACK) 
IMG_RUN_L.set_alpha(150)
IMG_RUN_R = load_image("RUN_R", (100, 200), TRANSPARENT_BLACK) 
IMG_RUN_R.set_alpha(150)

IMG_JUMP = load_image("JUMP", (200, 200), TRANSPARENT_BLACK)
IMG_JUMP.set_alpha(150)

# Tlačítka do horních rohů
IMG_PAUSE = load_image("PAUSE", (80, 80), TRANSPARENT_BLACK)
IMG_PAUSE.set_alpha(200)
IMG_MENU = load_image("MENU", (80, 80), TRANSPARENT_BLACK)
IMG_MENU.set_alpha(200)

SND_MINCE = load_sound("coin")
SND_HOUBA = load_sound("pipe")
SND_JUMP = load_sound("jump")

font_large = pygame.font.SysFont("comicsansms", 72, bold=True)
font_medium = pygame.font.SysFont("comicsansms", 40, bold=True)
font_small = pygame.font.SysFont("comicsansms", 28, bold=True)
font_tiny = pygame.font.SysFont("comicsansms", 18, bold=True)

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = IMG_CHRIS_00
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.vel_y = 0
        self.is_jumping = False
        self.speed = 7
        self.lives = 10
        self.invincible = 0
        self.animation_timer = 0
        self.facing_right = True

    def update(self, move_dir, jump_pressed, is_muted):
        self.vel_y += 0.8
        if self.vel_y > 15:
            self.vel_y = 15
            
        if not jump_pressed and self.vel_y < -5:
            self.vel_y = -5
            
        self.rect.y += self.vel_y

        is_moving = False
        if move_dir == 1:
            self.rect.x += self.speed
            is_moving = True
            self.facing_right = True
        elif move_dir == -1:
            self.rect.x -= self.speed
            is_moving = True
            self.facing_right = False

        if self.facing_right:
            img_stand = IMG_CHRIS_00
            img_run_1 = IMG_CHRIS_01
            img_run_2 = IMG_CHRIS_02
        else:
            img_stand = IMG_CHRIS_00_L
            img_run_1 = IMG_CHRIS_01_L
            img_run_2 = IMG_CHRIS_02_L

        if is_moving and not self.is_jumping:
            self.animation_timer += 0.2
            if int(self.animation_timer) % 2 == 0:
                self.image = img_run_1
            else:
                self.image = img_run_2
        else:
            self.image = img_stand

        if self.rect.bottom >= HEIGHT - 50:
            self.rect.bottom = HEIGHT - 50
            self.is_jumping = False
            self.vel_y = 0

        if self.rect.left < 50:
            self.rect.left = 50
        if self.rect.right > WIDTH / 2 + 100:
            self.rect.right = WIDTH / 2 + 100

        if jump_pressed and not self.is_jumping:
            self.vel_y = -21 
            self.is_jumping = True
            if not is_muted and SND_JUMP: SND_JUMP.play()

        if self.invincible > 0:
            self.invincible -= 1
            if self.invincible % 10 < 5:
                self.image.set_alpha(100)
            else:
                self.image.set_alpha(255)
        else:
            self.image.set_alpha(255)

class Obstacle(pygame.sprite.Sprite):
    def __init__(self, x, y, img_type, parent_brick=None):
        super().__init__()
        self.original_image = IMG_HOUBA_RED if img_type == 'red' else IMG_HOUBA_GREEN
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.bottom = y
        self.animation_timer = random.uniform(0, math.pi * 2) 
        self.parent_brick = parent_brick # Navázání na cihlu
        
    def update(self, scroll_speed):
        self.rect.x -= scroll_speed
        
        self.animation_timer += 0.1
        angle = math.sin(self.animation_timer) * 15 
        
        # Udržování přesné pozice houby na hýbající se cihle
        old_midbottom = list(self.rect.midbottom)
        if self.parent_brick:
            old_midbottom[1] = self.parent_brick.rect.top
            
        self.image = pygame.transform.rotate(self.original_image, angle)
        self.rect = self.image.get_rect(midbottom=old_midbottom)
        
        if self.rect.right < 0:
            self.kill()

class Brick(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = IMG_CIHLY
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.base_y = y
        self.rect.y = y
        self.timer = random.uniform(0, math.pi * 2)
        self.is_hit = False
        
    def update(self, scroll_speed):
        self.rect.x -= scroll_speed
        self.timer += 0.05
        self.rect.y = self.base_y + math.sin(self.timer) * 20
        if self.rect.right < 0:
            self.kill()

class Coin(pygame.sprite.Sprite):
    def __init__(self, x, y, parent_brick=None):
        super().__init__()
        self.image_1 = IMG_MINCE
        self.image_2 = IMG_MINCE2
        self.image = self.image_1
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.base_y = y
        self.rect.y = y
        self.timer = random.uniform(0, math.pi * 2)
        self.anim_timer = 0
        self.parent_brick = parent_brick
        
        if self.parent_brick:
            self.offset_y = y - parent_brick.rect.top

    def update(self, scroll_speed):
        self.rect.x -= scroll_speed
        self.timer += 0.1
        
        # Udržování relativní pozice mince nad hýbající se cihlou
        if self.parent_brick:
            self.rect.y = self.parent_brick.rect.top + self.offset_y + math.sin(self.timer) * 10
        else:
            self.rect.y = self.base_y + math.sin(self.timer) * 10
            
        self.anim_timer += 0.15
        if int(self.anim_timer) % 2 == 0:
            self.image = self.image_1
        else:
            self.image = self.image_2
        if self.rect.right < 0:
            self.kill()

def draw_text_with_bg(surface, text, font, text_color, bg_color, x, y, center=False):
    textobj = font.render(text, True, text_color)
    textrect = textobj.get_rect()
    if center:
        textrect.center = (x, y)
    else:
        textrect.topleft = (x, y)
        
    if bg_color != FULL_TRANSPARENT:
        bg_surf = pygame.Surface((textrect.width + 20, textrect.height + 10), pygame.SRCALPHA)
        bg_surf.fill(bg_color)
        bg_rect = bg_surf.get_rect(center=textrect.center)
        surface.blit(bg_surf, bg_rect)
        
    surface.blit(textobj, textrect)
    return textrect

def toggle_fullscreen():
    try:
        import platform
        if platform.system() == "Emscripten":
            import html
            import js
            document = js.document
            if not document.fullscreenElement:
                document.documentElement.requestFullscreen()
            else:
                if document.exitFullscreen:
                    document.exitFullscreen()
        else:
            pygame.display.toggle_fullscreen()
    except Exception as e:
        pass

async def main():
    pygame.mixer.stop()
    is_muted = False
    play_music("INTRO")
    
    state = "INTRO"
    score = 0
    bg_x = 0
    scroll_speed = 5
    
    game_over_sel = 0 
    active_touches = {}
    
    btn_start_rect = pygame.Rect(WIDTH//2 - 150, HEIGHT - 180, 300, 80)
    
    btn_run_l_rect = pygame.Rect(20, HEIGHT - 220, 100, 200)
    btn_run_r_rect = pygame.Rect(120, HEIGHT - 220, 100, 200)
    
    btn_jump_rect = pygame.Rect(WIDTH - 220, HEIGHT - 220, 200, 200)
    btn_restart = pygame.Rect(WIDTH//2 - 220, 360, 140, 80)
    btn_quit = pygame.Rect(WIDTH//2 + 80, 360, 140, 80)
    
    btn_pause_rect = pygame.Rect(10, 10, 80, 80) 
    btn_menu_rect = pygame.Rect(WIDTH - 90, 10, 80, 80) 
    
    menu_box = pygame.Rect(WIDTH//2 - 200, HEIGHT//2 - 200, 400, 400)
    btn_menu_go = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 - 120, 200, 50)
    btn_menu_mute = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 - 50, 200, 50)
    btn_menu_fs = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 20, 200, 50)
    btn_menu_exit = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 90, 200, 50)
    
    all_sprites = pygame.sprite.Group()
    obstacles = pygame.sprite.Group()
    bricks = pygame.sprite.Group()
    coins = pygame.sprite.Group()
    
    chris = Player(150, HEIGHT - 200) 
    all_sprites.add(chris)

    spawn_timer = 0
    running = True

    popup_text = ""
    popup_color = WHITE
    popup_timer = 0
    popup_y = HEIGHT // 2

    while running:
        clock.tick(FPS)
        keys = pygame.key.get_pressed()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                
            if hasattr(pygame, 'FINGERDOWN'):
                if event.type == pygame.FINGERDOWN or event.type == pygame.FINGERMOTION:
                    active_touches[event.finger_id] = (event.x * WIDTH, event.y * HEIGHT)
                elif event.type == pygame.FINGERUP:
                    active_touches.pop(event.finger_id, None)
                    
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    if state == "PLAYING":
                        state = "PAUSED"
                        if not is_muted: pygame.mixer.music.pause()
                    elif state == "PAUSED":
                        state = "PLAYING"
                        if not is_muted: pygame.mixer.music.unpause()
                
                if state == "INTRO" and (event.key == pygame.K_SPACE or event.key == pygame.K_RETURN or event.key == pygame.K_KP_ENTER):
                    state = "PLAYING"
                    if not is_muted: play_music("HRA")

                if state == "GAME_OVER":
                    if event.key == pygame.K_LEFT:
                        game_over_sel = 0
                    elif event.key == pygame.K_RIGHT:
                        game_over_sel = 1
                    elif event.key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                        if game_over_sel == 0:
                            await main()
                            return
                        else:
                            running = False
                    elif event.key == pygame.K_ESCAPE:
                        running = False
            
            click_pos = None
            if event.type == pygame.MOUSEBUTTONDOWN:
                click_pos = event.pos
            elif hasattr(pygame, 'FINGERDOWN') and event.type == pygame.FINGERDOWN:
                click_pos = (event.x * WIDTH, event.y * HEIGHT)
                
            if click_pos:
                if state == "INTRO":
                    if btn_start_rect.collidepoint(click_pos):
                        state = "PLAYING"
                        if not is_muted: play_music("HRA")
                        
                elif state == "GAME_OVER":
                    if btn_restart.collidepoint(click_pos):
                        await main()
                        return
                    if btn_quit.collidepoint(click_pos):
                        running = False
                        
                elif state == "PLAYING":
                    if btn_pause_rect.collidepoint(click_pos):
                        state = "PAUSED"
                        if not is_muted: pygame.mixer.music.pause()
                    elif btn_menu_rect.collidepoint(click_pos):
                        state = "IN_MENU"
                        if not is_muted: pygame.mixer.music.pause()
                        
                elif state == "PAUSED":
                    if btn_pause_rect.collidepoint(click_pos):
                        state = "PLAYING"
                        if not is_muted: pygame.mixer.music.unpause()
                        
                elif state == "IN_MENU":
                    if btn_menu_go.collidepoint(click_pos):
                        state = "PLAYING"
                        if not is_muted: pygame.mixer.music.unpause()
                    elif btn_menu_mute.collidepoint(click_pos):
                        is_muted = not is_muted
                        if is_muted:
                            pygame.mixer.music.pause()
                        else:
                            pygame.mixer.music.unpause()
                    elif btn_menu_fs.collidepoint(click_pos):
                        toggle_fullscreen()
                    elif btn_menu_exit.collidepoint(click_pos):
                        running = False

        if state == "INTRO":
            screen.blit(IMG_UVODNI, (0, 0))
            
            s_btn = pygame.Surface((btn_start_rect.width, btn_start_rect.height), pygame.SRCALPHA)
            pygame.draw.rect(s_btn, TRANSPARENT_RED, s_btn.get_rect(), border_radius=15)
            pygame.draw.rect(s_btn, GREEN, s_btn.get_rect(), 4, border_radius=15)
            screen.blit(s_btn, btn_start_rect.topleft)
            
            draw_text_with_bg(screen, "START", font_medium, WHITE, FULL_TRANSPARENT, btn_start_rect.centerx, btn_start_rect.centery, center=True)
        
        elif state == "PLAYING" or state == "PAUSED" or state == "IN_MENU":
            if state == "PLAYING":
                run_r_mouse = pygame.mouse.get_pressed()[0] and btn_run_r_rect.collidepoint(pygame.mouse.get_pos())
                run_r_touch = any(btn_run_r_rect.collidepoint(tx, ty) for tx, ty in active_touches.values())
                run_right = keys[pygame.K_SPACE] or keys[pygame.K_RIGHT] or run_r_mouse or run_r_touch
                
                run_l_mouse = pygame.mouse.get_pressed()[0] and btn_run_l_rect.collidepoint(pygame.mouse.get_pos())
                run_l_touch = any(btn_run_l_rect.collidepoint(tx, ty) for tx, ty in active_touches.values())
                run_left = keys[pygame.K_LEFT] or run_l_mouse or run_l_touch
                
                move_dir = 0
                if run_right:
                    move_dir = 1
                elif run_left:
                    move_dir = -1
                
                jump_mouse = pygame.mouse.get_pressed()[0] and btn_jump_rect.collidepoint(pygame.mouse.get_pos())
                jump_touch = any(btn_jump_rect.collidepoint(tx, ty) for tx, ty in active_touches.values())
                jump_pressed = keys[pygame.K_UP] or jump_mouse or jump_touch
                
                current_scroll = scroll_speed if move_dir == 1 else 0
                bg_x -= current_scroll
                if bg_x <= -WIDTH:
                    bg_x = 0
                    
                if current_scroll > 0:
                    spawn_timer += 1
                    if spawn_timer > 100:
                        spawn_timer = 0
                        rnd = random.randint(1, 10)
                        spawn_x = WIDTH + 50
                        
                        # =========================================================================
                        # ZDE MŮŽEŠ UPRAVIT VÝŠKU CIHEL
                        # Původně bylo HEIGHT - 250, nyní je o 80px výš (HEIGHT - 330)
                        # =========================================================================
                        base_brick_y = HEIGHT - 330
                        
                        if rnd <= 3:
                            obs = Obstacle(spawn_x, HEIGHT - 50, random.choice(['red', 'green']))
                            obstacles.add(obs)
                            all_sprites.add(obs)
                        elif rnd <= 6:
                            # Cihla se spawnuje v nové výšce
                            brick = Brick(spawn_x, base_brick_y + random.randint(-20, 20))
                            bricks.add(brick)
                            all_sprites.add(brick)
                            
                            if random.random() < 0.3:
                                # Houba navázaná na cihlu (parent_brick)
                                obs = Obstacle(spawn_x + 45, brick.rect.top, random.choice(['red', 'green']), parent_brick=brick)
                                obstacles.add(obs)
                                all_sprites.add(obs)
                            else:
                                num_coins = random.randint(1, 3)
                                for i in range(num_coins):
                                    # Mince navázaná na cihlu (parent_brick)
                                    coin = Coin(spawn_x + 20 + (i * 45), brick.rect.top - 50, parent_brick=brick)
                                    coins.add(coin)
                                    all_sprites.add(coin)
                        else:
                            num_coins = random.randint(1, 2)
                            base_y = HEIGHT - 150 - random.randint(0, 150)
                            for i in range(num_coins):
                                coin = Coin(spawn_x + (i * 45), base_y)
                                coins.add(coin)
                                all_sprites.add(coin)

                for s in all_sprites:
                    if s == chris:
                        s.update(move_dir, jump_pressed, is_muted)
                    else:
                        s.update(current_scroll)

                hit_bricks = pygame.sprite.spritecollide(chris, bricks, False)
                for brick in hit_bricks:
                    if chris.vel_y >= 0 and chris.rect.bottom <= brick.rect.centery + 25:
                        chris.rect.bottom = brick.rect.top
                        chris.is_jumping = False
                        chris.vel_y = 0
                    elif chris.vel_y < 0 and chris.rect.top >= brick.rect.centery - 10:
                        chris.rect.top = brick.rect.bottom
                        chris.vel_y = 2 
                        
                        if not brick.is_hit and (brick.rect.left + 50 <= chris.rect.centerx <= brick.rect.right - 50):
                            brick.is_hit = True
                            
                            if random.random() < 0.85:
                                amount = random.randint(1, 5)
                                score += amount
                                popup_text = f"+{amount} MINCÍ"
                                popup_color = GOLD
                                if not is_muted and SND_MINCE: SND_MINCE.play()
                            else:
                                chris.lives += 1
                                popup_text = "+1 ŽIVOT"
                                popup_color = RED
                                if not is_muted and SND_JUMP: SND_JUMP.play()
                            
                            popup_timer = 60
                            popup_y = HEIGHT // 2

                hit_obs = pygame.sprite.spritecollide(chris, obstacles, False)
                for obs in hit_obs:
                    if chris.vel_y > 0 and chris.rect.bottom <= obs.rect.top + 30:
                        chris.rect.bottom = obs.rect.top
                        chris.vel_y = -14 
                        if not is_muted and SND_JUMP: SND_JUMP.play()
                    else:
                        forgiving_hitbox = obs.rect.inflate(-30, -20)
                        if chris.rect.colliderect(forgiving_hitbox):
                            if chris.invincible <= 0:
                                chris.lives -= 1
                                chris.invincible = 90
                                if not is_muted and SND_HOUBA: SND_HOUBA.play()
                                if chris.lives <= 0:
                                    state = "GAME_OVER"
                                    if not is_muted: play_music("KONEC")

                hit_coins = pygame.sprite.spritecollide(chris, coins, True)
                if hit_coins:
                    score += len(hit_coins)
                    if not is_muted and SND_MINCE: SND_MINCE.play()

            screen.blit(IMG_POZADI, (bg_x, 0))
            screen.blit(IMG_POZADI, (bg_x + WIDTH, 0))
            all_sprites.draw(screen)
            
            if popup_timer > 0:
                popup_timer -= 1
                popup_y -= 1 
                draw_text_with_bg(screen, popup_text, font_large, popup_color, TRANSPARENT_BLACK, WIDTH//2, int(popup_y), center=True)
            
            napis_rect = screen.blit(IMG_NAPIS, (WIDTH//2 - IMG_NAPIS.get_width()//2, 10))
            
            pos_x_zivoty = napis_rect.left - 250
            pos_x_mince = napis_rect.right + 70
            
            draw_text_with_bg(screen, f"Životy: {chris.lives}", font_medium, RED, TRANSPARENT_BLACK, pos_x_zivoty, 20)
            draw_text_with_bg(screen, f"Mince: {score}", font_medium, GOLD, TRANSPARENT_BLACK, pos_x_mince, 20)
            
            screen.blit(IMG_RUN_L, btn_run_l_rect.topleft)
            screen.blit(IMG_RUN_R, btn_run_r_rect.topleft)
            screen.blit(IMG_JUMP, btn_jump_rect.topleft)
            
            screen.blit(IMG_PAUSE, btn_pause_rect.topleft)
            screen.blit(IMG_MENU, btn_menu_rect.topleft)

            if state == "PAUSED":
                draw_text_with_bg(screen, "PAUZA", font_large, WHITE, TRANSPARENT_BLACK, WIDTH/2, HEIGHT/2, center=True)
                
            elif state == "IN_MENU":
                overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
                overlay.fill((0, 0, 0, 180))
                screen.blit(overlay, (0,0))
                
                pygame.draw.rect(screen, (50, 50, 50), menu_box, border_radius=20)
                pygame.draw.rect(screen, WHITE, menu_box, 3, border_radius=20)
                draw_text_with_bg(screen, "MENU", font_medium, WHITE, FULL_TRANSPARENT, WIDTH/2, menu_box.top + 40, center=True)
                
                pygame.draw.rect(screen, GREEN, btn_menu_go, border_radius=10)
                draw_text_with_bg(screen, "GO", font_small, BLACK, FULL_TRANSPARENT, btn_menu_go.centerx, btn_menu_go.centery, center=True)
                
                mute_text = "SOUND: OFF" if is_muted else "SOUND: ON"
                mute_color = RED if is_muted else SKY_BLUE
                pygame.draw.rect(screen, mute_color, btn_menu_mute, border_radius=10)
                draw_text_with_bg(screen, mute_text, font_small, BLACK, FULL_TRANSPARENT, btn_menu_mute.centerx, btn_menu_mute.centery, center=True)
                
                pygame.draw.rect(screen, GOLD, btn_menu_fs, border_radius=10)
                draw_text_with_bg(screen, "FULL SCREEN", font_small, BLACK, FULL_TRANSPARENT, btn_menu_fs.centerx, btn_menu_fs.centery, center=True)
                
                pygame.draw.rect(screen, RED, btn_menu_exit, border_radius=10)
                draw_text_with_bg(screen, "EXIT GAME", font_small, WHITE, FULL_TRANSPARENT, btn_menu_exit.centerx, btn_menu_exit.centery, center=True)

        elif state == "GAME_OVER":
            screen.blit(IMG_KONEC, (0, 0))
            draw_text_with_bg(screen, "GAME OVER", font_large, RED, TRANSPARENT_BLACK, WIDTH/2, 100, center=True)
            draw_text_with_bg(screen, f"Nasbírané mince: {score}", font_medium, GOLD, TRANSPARENT_BLACK, WIDTH/2, 200, center=True)
            
            color_restart = GREEN if game_over_sel == 0 else WHITE
            color_quit = RED if game_over_sel == 1 else WHITE
            
            btn_restart = draw_text_with_bg(screen, " ZNOVU ", font_medium, color_restart, TRANSPARENT_BLACK, WIDTH/2 - 150, 400, center=True)
            pygame.draw.rect(screen, color_restart, btn_restart.inflate(10, 10), 4)
            
            btn_quit = draw_text_with_bg(screen, " UKONČIT ", font_medium, color_quit, TRANSPARENT_BLACK, WIDTH/2 + 150, 400, center=True)
            pygame.draw.rect(screen, color_quit, btn_quit.inflate(10, 10), 4)
            
            draw_text_with_bg(screen, "VYROBIL TÁTA", font_tiny, WHITE, TRANSPARENT_BLACK, WIDTH/2, HEIGHT - 20, center=True)

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())
