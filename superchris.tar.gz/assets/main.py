import pygame
import os
import math
import random
import sys
import asyncio

# Inicializace Pygame
pygame.init()
try:
    # Snížená frekvence na 22050Hz a mono (channels=1) pro čistý webový zvuk bez zkreslení
    pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=8192)
except Exception:
    pass

# Nastavení okna
WIDTH, HEIGHT = 1200, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Super Mario a Chris")

# Barvy
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
GOLD = (255, 215, 0)
SKY_BLUE = (135, 206, 235)
TRANSPARENT_BLACK = (0, 0, 0, 150)
FULL_TRANSPARENT = (0, 0, 0, 0)

FPS = 60
clock = pygame.time.Clock()
PIC_DIR = "PIC"
AUDIO_DIR = "AUDIO"

if not os.path.exists(PIC_DIR):
    os.makedirs(PIC_DIR)
if not os.path.exists(AUDIO_DIR):
    os.makedirs(AUDIO_DIR)

def load_image(name, size=None, color=RED):
    path_png = os.path.join(PIC_DIR, name + ".png")
    path_jpg = os.path.join(PIC_DIR, name + ".jpg")
    path_PNG_upper = os.path.join(PIC_DIR, name + ".PNG")
    
    img = None
    if os.path.exists(path_png):
        img = pygame.image.load(path_png).convert_alpha()
    elif os.path.exists(path_jpg):
        img = pygame.image.load(path_jpg).convert_alpha()
    elif os.path.exists(path_PNG_upper):
        img = pygame.image.load(path_PNG_upper).convert_alpha()
        
    if img:
        if size:
            img = pygame.transform.scale(img, size)
        return img
    else:
        surf = pygame.Surface(size if size else (50, 50), pygame.SRCALPHA)
        surf.fill(color)
        return surf

def load_sound(name):
    for ext in [".ogg", ".mp3", ".wav"]:
        path = os.path.join(AUDIO_DIR, name + ext)
        if os.path.exists(path):
            try:
                return pygame.mixer.Sound(path)
            except Exception:
                return None
    return None

def play_music(name):
    for ext in [".ogg", ".mp3", ".wav"]:
        path = os.path.join(AUDIO_DIR, name + ext)
        if os.path.exists(path):
            try:
                pygame.mixer.music.load(path)
                pygame.mixer.music.play(-1)
                return True
            except Exception:
                return False
    return False

# Načtení grafiky
IMG_UVODNI = load_image("UVODNI", (WIDTH, HEIGHT), SKY_BLUE)
IMG_POZADI = load_image("POZADI", (WIDTH, HEIGHT), SKY_BLUE)
IMG_KONEC = load_image("KONEC", (WIDTH, HEIGHT), BLACK)
IMG_CHRIS_00 = load_image("CHRIS_00", (120, 150), (0, 0, 255)) 
IMG_CHRIS_01 = load_image("CHRIS_01", (120, 150), (0, 255, 255)) 
IMG_CHRIS_02 = load_image("CHRIS_02", (120, 150), (255, 255, 0)) 
IMG_HOUBA_RED = load_image("HOUBA_RED", (60, 60), RED)
IMG_HOUBA_GREEN = load_image("HOUBA_GREEN", (60, 60), GREEN) 
IMG_MINCE = load_image("MINCE", (40, 40), GOLD)
IMG_MINCE2 = load_image("MINCE2", (40, 40), GOLD) 
IMG_CIHLY = load_image("CIHLY", (150, 45), (139, 69, 19))
IMG_NAPIS = load_image("NAPIS", (600, 60), TRANSPARENT_BLACK) 

IMG_RUN = load_image("RUN", (200, 200), TRANSPARENT_BLACK)
IMG_RUN.set_alpha(150)
IMG_JUMP = load_image("JUMP", (200, 200), TRANSPARENT_BLACK)
IMG_JUMP.set_alpha(150)

SND_MINCE = load_sound("coin")
SND_HOUBA = load_sound("pipe")
SND_JUMP = load_sound("jump")

font_large = pygame.font.SysFont("comicsansms", 72, bold=True)
font_medium = pygame.font.SysFont("comicsansms", 48, bold=True)
font_small = pygame.font.SysFont("comicsansms", 32, bold=True)
font_tiny = pygame.font.SysFont("comicsansms", 18, bold=True)
font_intro_blink = pygame.font.SysFont("comicsansms", 24, bold=True)

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image_stand = IMG_CHRIS_00
        self.image_run_1 = IMG_CHRIS_01
        self.image_run_2 = IMG_CHRIS_02
        self.image = self.image_stand
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.vel_y = 0
        self.is_jumping = False
        self.speed = 7
        self.lives = 10
        self.invincible = 0
        self.animation_timer = 0

    def reset(self, x, y):
        self.rect.x = x
        self.rect.y = y
        self.vel_y = 0
        self.is_jumping = False
        self.lives = 10
        self.invincible = 0
        self.animation_timer = 0
        self.image = self.image_stand

    def update(self, run_pressed, jump_pressed):
        self.vel_y += 0.8
        if self.vel_y > 15:
            self.vel_y = 15
            
        if not jump_pressed and self.vel_y < -5:
            self.vel_y = -5
            
        self.rect.y += self.vel_y

        is_moving = False
        if run_pressed:
            self.rect.x += self.speed
            is_moving = True

        if is_moving and not self.is_jumping:
            self.animation_timer += 0.2
            if int(self.animation_timer) % 2 == 0:
                self.image = self.image_run_1
            else:
                self.image = self.image_run_2
        else:
            self.image = self.image_stand

        if self.rect.bottom >= HEIGHT - 50:
            self.rect.bottom = HEIGHT - 50
            self.is_jumping = False
            self.vel_y = 0

        if self.rect.left < 50:
            self.rect.left = 50
        if self.rect.right > WIDTH / 2 + 100:
            self.rect.right = WIDTH / 2 + 100

        if jump_pressed and not self.is_jumping:
            self.vel_y = -21 
            self.is_jumping = True
            if SND_JUMP: SND_JUMP.play()

        if self.invincible > 0:
            self.invincible -= 1
            if self.invincible % 10 < 5:
                self.image.set_alpha(100)
            else:
                self.image.set_alpha(255)
        else:
            self.image.set_alpha(255)

class Obstacle(pygame.sprite.Sprite):
    def __init__(self, x, y, img_type):
        super().__init__()
        self.original_image = IMG_HOUBA_RED if img_type == 'red' else IMG_HOUBA_GREEN
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.bottom = y
        self.animation_timer = random.uniform(0, math.pi * 2) 
        
    def update(self, scroll_speed):
        self.rect.x -= scroll_speed
        self.animation_timer += 0.1
        angle = math.sin(self.animation_timer) * 15 
        old_midbottom = self.rect.midbottom 
        self.image = pygame.transform.rotate(self.original_image, angle)
        self.rect = self.image.get_rect(midbottom=old_midbottom)
        if self.rect.right < 0:
            self.kill()

class Brick(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = IMG_CIHLY
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.base_y = y
        self.rect.y = y
        self.timer = random.uniform(0, math.pi * 2)
        
    def update(self, scroll_speed):
        self.rect.x -= scroll_speed
        self.timer += 0.05
        self.rect.y = self.base_y + math.sin(self.timer) * 20
        if self.rect.right < 0:
            self.kill()

class Coin(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image_1 = IMG_MINCE
        self.image_2 = IMG_MINCE2
        self.image = self.image_1
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.base_y = y
        self.rect.y = y
        self.timer = random.uniform(0, math.pi * 2)
        self.anim_timer = 0

    def update(self, scroll_speed):
        self.rect.x -= scroll_speed
        self.timer += 0.1
        self.rect.y = self.base_y + math.sin(self.timer) * 10
        self.anim_timer += 0.15
        if int(self.anim_timer) % 2 == 0:
            self.image = self.image_1
        else:
            self.image = self.image_2
        if self.rect.right < 0:
            self.kill()

def draw_text_with_bg(surface, text, font, text_color, bg_color, x, y, center=False):
    textobj = font.render(text, True, text_color)
    textrect = textobj.get_rect()
    if center:
        textrect.center = (x, y)
    else:
        textrect.topleft = (x, y)
        
    bg_surf = pygame.Surface((textrect.width + 20, textrect.height + 10), pygame.SRCALPHA)
    bg_surf.fill(bg_color)
    bg_rect = bg_surf.get_rect(center=textrect.center)
    
    surface.blit(bg_surf, bg_rect)
    surface.blit(textobj, textrect)
    return textrect

async def main():
    try:
        pygame.mixer.stop()
    except Exception:
        pass
    play_music("INTRO")
    
    state = "INTRO"
    score = 0
    bg_x = 0
    scroll_speed = 5
    
    game_over_sel = 0
    active_touches = {}
    
    btn_start_rect = pygame.Rect(WIDTH//2 - 150, HEIGHT - 180, 300, 80)
    btn_run_rect = pygame.Rect(20, HEIGHT - 220, 200, 200)
    btn_jump_rect = pygame.Rect(WIDTH - 220, HEIGHT - 220, 200, 200)
    
    btn_restart = pygame.Rect(WIDTH//2 - 220, 360, 140, 80)
    btn_quit = pygame.Rect(WIDTH//2 + 80, 360, 140, 80)
    
    all_sprites = pygame.sprite.Group()
    obstacles = pygame.sprite.Group()
    bricks = pygame.sprite.Group()
    coins = pygame.sprite.Group()
    
    chris = Player(150, HEIGHT - 200)
    all_sprites.add(chris)

    def restart_game():
        nonlocal score, bg_x, spawn_timer, state, paused
        score = 0
        bg_x = 0
        spawn_timer = 0
        paused = False
        obstacles.empty()
        bricks.empty()
        coins.empty()
        all_sprites.empty()
        chris.reset(150, HEIGHT - 200)
        all_sprites.add(chris)
        state = "PLAYING"
        play_music("HRA")

    spawn_timer = 0
    intro_blink_timer = 0
    running = True
    paused = False

    while running:
        clock.tick(FPS)
        keys = pygame.key.get_pressed()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                
            if hasattr(pygame, 'FINGERDOWN'):
                if event.type == pygame.FINGERDOWN or event.type == pygame.FINGERMOTION:
                    active_touches[event.finger_id] = (event.x * WIDTH, event.y * HEIGHT)
                elif event.type == pygame.FINGERUP:
                    active_touches.pop(event.finger_id, None)
                    
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p and state == "PLAYING":
                    paused = not paused
                    if paused:
                        try:
                            pygame.mixer.music.pause()
                        except Exception:
                            pass
                    else:
                        try:
                            pygame.mixer.music.unpause()
                        except Exception:
                            pass
                
                if state == "INTRO" and (event.key == pygame.K_SPACE or event.key == pygame.K_RETURN or event.key == pygame.K_KP_ENTER):
                    state = "PLAYING"
                    play_music("HRA")

                if state == "GAME_OVER":
                    if event.key == pygame.K_LEFT:
                        game_over_sel = 0
                    elif event.key == pygame.K_RIGHT:
                        game_over_sel = 1
                    elif event.key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                        if game_over_sel == 0:
                            restart_game()
                        else:
                            running = False
                    elif event.key == pygame.K_ESCAPE:
                        running = False
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = event.pos
                if state == "INTRO":
                    if btn_start_rect.collidepoint(mouse_pos):
                        state = "PLAYING"
                        play_music("HRA")
                elif state == "GAME_OVER":
                    if btn_restart.collidepoint(mouse_pos):
                        restart_game()
                    elif btn_quit.collidepoint(mouse_pos):
                        running = False
            
            if hasattr(pygame, 'FINGERDOWN') and event.type == pygame.FINGERDOWN:
                touch_pos = (event.x * WIDTH, event.y * HEIGHT)
                if state == "INTRO":
                    if btn_start_rect.collidepoint(touch_pos):
                        state = "PLAYING"
                        play_music("HRA")
                elif state == "GAME_OVER":
                    if btn_restart.collidepoint(touch_pos):
                        restart_game()
                    elif btn_quit.collidepoint(touch_pos):
                        running = False

        if state == "INTRO":
            screen.blit(IMG_UVODNI, (0, 0))
            pygame.draw.rect(screen, GREEN, btn_start_rect, 4, border_radius=15)
            draw_text_with_bg(screen, "START", font_medium, WHITE, FULL_TRANSPARENT, btn_start_rect.centerx, btn_start_rect.centery, center=True)
            
            intro_blink_timer += 1
            if intro_blink_timer % 60 < 30:
                draw_text_with_bg(screen, "ZMAČKNI SPACE NEBO ENTER PRO START", font_intro_blink, WHITE, TRANSPARENT_BLACK, WIDTH/2, HEIGHT - 70, center=True)
        
        elif state == "PLAYING" and not paused:
            run_touch = any(btn_run_rect.collidepoint(tx, ty) for tx, ty in active_touches.values())
            jump_touch = any(btn_jump_rect.collidepoint(tx, ty) for tx, ty in active_touches.values())
            
            mouse_pressed = pygame.mouse.get_pressed()[0]
            mouse_pos = pygame.mouse.get_pos()
            run_mouse = mouse_pressed and btn_run_rect.collidepoint(mouse_pos)
            jump_mouse = mouse_pressed and btn_jump_rect.collidepoint(mouse_pos)
            
            run_pressed = keys[pygame.K_SPACE] or run_mouse or run_touch
            jump_pressed = keys[pygame.K_UP] or jump_mouse or jump_touch
            
            current_scroll = scroll_speed if run_pressed else 0
            bg_x -= current_scroll
            if bg_x <= -WIDTH:
                bg_x = 0
                
            if current_scroll > 0:
                spawn_timer += 1
                if spawn_timer > 100:
                    spawn_timer = 0
                    rnd = random.randint(1, 10)
                    spawn_x = WIDTH + 50
                    if rnd <= 3:
                        obs = Obstacle(spawn_x, HEIGHT - 50, random.choice(['red', 'green']))
                        obstacles.add(obs)
                        all_sprites.add(obs)
                    elif rnd <= 6:
                        brick = Brick(spawn_x, HEIGHT - 250 + random.randint(-20, 20))
                        bricks.add(brick)
                        all_sprites.add(brick)
                        
                        if random.random() < 0.3:
                            obs = Obstacle(spawn_x + 45, brick.rect.top, random.choice(['red', 'green']))
                            obstacles.add(obs)
                            all_sprites.add(obs)
                        else:
                            num_coins = random.randint(1, 3)
                            for i in range(num_coins):
                                coin = Coin(spawn_x + 20 + (i * 45), brick.rect.top - 50)
                                coins.add(coin)
                                all_sprites.add(coin)
                    else:
                        num_coins = random.randint(1, 2)
                        base_y = HEIGHT - 150 - random.randint(0, 150)
                        for i in range(num_coins):
                            coin = Coin(spawn_x + (i * 45), base_y)
                            coins.add(coin)
                            all_sprites.add(coin)

            for s in all_sprites:
                if s == chris:
                    s.update(run_pressed, jump_pressed)
                else:
                    s.update(current_scroll)

            hit_bricks = pygame.sprite.spritecollide(chris, bricks, False)
            if hit_bricks and chris.vel_y >= 0:
                brick = hit_bricks[0]
                if chris.rect.bottom <= brick.rect.centery + 25:
                    chris.rect.bottom = brick.rect.top
                    chris.is_jumping = False
                    chris.vel_y = 0

            hit_obs = pygame.sprite.spritecollide(chris, obstacles, False)
            for obs in hit_obs:
                if chris.vel_y > 0 and chris.rect.bottom <= obs.rect.top + 30:
                    chris.rect.bottom = obs.rect.top
                    chris.vel_y = -14 
                    if SND_JUMP: SND_JUMP.play()
                else:
                    forgiving_hitbox = obs.rect.inflate(-30, -20)
                    if chris.rect.colliderect(forgiving_hitbox):
                        if chris.invincible <= 0:
                            chris.lives -= 1
                            chris.invincible = 90
                            if SND_HOUBA: SND_HOUBA.play()
                            if chris.lives <= 0:
                                state = "GAME_OVER"
                                play_music("KONEC")

            hit_coins = pygame.sprite.spritecollide(chris, coins, True)
            if hit_coins:
                score += len(hit_coins)
                if SND_MINCE: SND_MINCE.play()

            screen.blit(IMG_POZADI, (bg_x, 0))
            screen.blit(IMG_POZADI, (bg_x + WIDTH, 0))
            all_sprites.draw(screen)
            
            draw_text_with_bg(screen, f"Životy: {chris.lives}", font_medium, RED, TRANSPARENT_BLACK, 20, 20)
            draw_text_with_bg(screen, f"Mince: {score}", font_medium, GOLD, TRANSPARENT_BLACK, WIDTH - 300, 20)
            
            screen.blit(IMG_NAPIS, (WIDTH//2 - IMG_NAPIS.get_width()//2, 10))
            
            screen.blit(IMG_RUN, btn_run_rect.topleft)
            screen.blit(IMG_JUMP, btn_jump_rect.topleft)

        elif state == "PLAYING" and paused:
            draw_text_with_bg(screen, "PAUZA", font_large, WHITE, TRANSPARENT_BLACK, WIDTH/2, HEIGHT/2, center=True)

        elif state == "GAME_OVER":
            screen.blit(IMG_KONEC, (0, 0))
            draw_text_with_bg(screen, "GAME OVER", font_large, RED, TRANSPARENT_BLACK, WIDTH/2, 100, center=True)
            draw_text_with_bg(screen, f"Nasbírané mince: {score}", font_medium, GOLD, TRANSPARENT_BLACK, WIDTH/2, 200, center=True)
            
            color_restart = GREEN if game_over_sel == 0 else WHITE
            color_quit = RED if game_over_sel == 1 else WHITE
            
            btn_restart = draw_text_with_bg(screen, " ZNOVU ", font_medium, color_restart, TRANSPARENT_BLACK, WIDTH/2 - 150, 400, center=True)
            pygame.draw.rect(screen, color_restart, btn_restart.inflate(10, 10), 4)
            
            btn_quit = draw_text_with_bg(screen, " UKONČIT ", font_medium, color_quit, TRANSPARENT_BLACK, WIDTH/2 + 150, 400, center=True)
            pygame.draw.rect(screen, color_quit, btn_quit.inflate(10, 10), 4)
            
            draw_text_with_bg(screen, "VYROBIL TÁTA", font_tiny, WHITE, TRANSPARENT_BLACK, WIDTH/2, HEIGHT - 20, center=True)

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())
